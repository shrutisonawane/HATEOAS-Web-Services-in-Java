/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.appeal.representations;
import com.appeal.activities.InvalidAppealException;
import com.appeal.model.AppealStatus;
import java.io.ByteArrayInputStream;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.appeal.model.*;
import javax.persistence.criteria.Order;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Shruti Sonawane
 */
@XmlRootElement(name = "appeal", namespace = Representation.APPEAL_SYS_NAMESPACE)
public class AppealRepresentation extends Representation
{
    private static final Logger LOG = LoggerFactory.getLogger(AppealRepresentation.class);
    
    @XmlElement(name = "itemName", namespace = Representation.APPEAL_SYS_NAMESPACE)
    private String itemName;
    
     @XmlElement(name = "appealContent", namespace = Representation.APPEAL_SYS_NAMESPACE)
     private String appealContent;
     
     @XmlElement(name = "status", namespace = Representation.APPEAL_SYS_NAMESPACE)
     private AppealStatus status;
    
     
     AppealRepresentation()
     {
         LOG.debug("In AppealRepresentation Constructor");
     }
     
     public static AppealRepresentation fromXmlString(String xmlRepresentation) 
     {
        LOG.info("Creating an Appeal object from the XML = {}", xmlRepresentation);
                
        AppealRepresentation appealRepresentation = null;     
        try 
        {
            JAXBContext context = JAXBContext.newInstance(AppealRepresentation.class);
            Unmarshaller unmarshaller = context.createUnmarshaller();
            appealRepresentation = (AppealRepresentation) unmarshaller.unmarshal(new ByteArrayInputStream(xmlRepresentation.getBytes()));
        } 
        catch (Exception e) 
        {
            throw new InvalidAppealException(e);
        }
        
        LOG.debug("Generated the object {}", appealRepresentation);
        return appealRepresentation;
    }
     
     public AppealRepresentation(Appeal appeal, Link... links) {
        LOG.info("Creating an Appeal Representation for appeal = {} and links = {}", appeal.toString(), links.toString());
        
        try 
        {
            this.appealContent=appeal.getAppealContent();
            this.itemName = appeal.getItemName();
            this.status = appeal.getStatus();
            this.links = java.util.Arrays.asList(links);
        } 
        catch (Exception ex) 
        {
          throw new InvalidAppealException(ex);
        }
        
        LOG.debug("Created the OrderRepresentation {}", this);
    }
     
     public Appeal getAppeal() 
     {
        LOG.info("Retrieving the Appeal Representation");
        if (itemName == null || appealContent == null || status== null) 
        {
            throw new InvalidAppealException();
        }
              
        Appeal appeal = new Appeal(itemName, appealContent, status);
        
        LOG.debug("Retrieving the Appeal Representation {}", appeal);

        return appeal;
    }
     
     public static AppealRepresentation createResponseAppealRepresentation(Appeal appeal, AppealsURI appealUri) 
     {
        LOG.info("Creating a Response Appeal for appeal = {} and appeal URI", appeal.toString(), appealUri.toString());
        
        AppealRepresentation appRep;     
        
        AppealsURI processUri = new AppealsURI(appealUri.getBaseUri() + "/process/" + appealUri.getId().toString());
        LOG.debug("Processing URI = {}", processUri);
        
        if(appeal.getStatus() == AppealStatus.NEW) 
        {
            LOG.debug("The appeal status is {}", AppealStatus.NEW);
            appRep = new AppealRepresentation(appeal, 
                    new Link(RELATIONS_URI + "delete", appealUri), 
                    new Link(RELATIONS_URI + "process", processUri), 
                    new Link(RELATIONS_URI + "update", appealUri),
                    new Link(Representation.SELF_REL_VALUE, appealUri));
        } 
        else if(appeal.getStatus() == AppealStatus.UNDER_REVIEW) 
        {
            LOG.debug("The appeal status is {}", AppealStatus.UNDER_REVIEW);
            appRep = new AppealRepresentation(appeal, new Link(Representation.SELF_REL_VALUE, appealUri));
        } 
        else if((appeal.getStatus() == AppealStatus.ACCEPTED) || (appeal.getStatus() == AppealStatus.REJECTED)) 
        {
            LOG.debug("The appeal status is {}", appeal.getStatus());
            if(appeal.getStatus()== AppealStatus.ACCEPTED)
                appRep = new AppealRepresentation(appeal, new Link(Representation.RELATIONS_URI +"accepted" , appealUri));
            else
                appRep = new AppealRepresentation(appeal, new Link(Representation.RELATIONS_URI +"rejected" , appealUri));
        } 
        else if(appeal.getStatus() == AppealStatus.FORGOTTEN) 
        {
            LOG.debug("The appeal status is {}", AppealStatus.FORGOTTEN);
            appRep = new AppealRepresentation(appeal,
                    new Link(RELATIONS_URI + "delete", appealUri), 
                    new Link(RELATIONS_URI + "process", processUri), 
                    new Link(RELATIONS_URI + "update", appealUri),
                    new Link(Representation.SELF_REL_VALUE, appealUri));            
        } 
        else 
        {
            LOG.debug("The appeal status is in an unknown status");
            throw new RuntimeException("Unknown Appeal Status");
        }
        
        LOG.debug("The appeal representation created for the Create Response Appeal Representation is {}", appRep);
        
        return appRep;
    }
     
      public Link getDeleteLink() 
      {
        LOG.info("Retrieving the Delete link ");
        return getLinkByName(RELATIONS_URI + "delete");
    }

    public Link getProcessLink() 
    {
        LOG.info("Retrieving the Process link ");
        return getLinkByName(RELATIONS_URI + "get");
    }

    public Link getUpdateLink() 
    {
        LOG.info("Retrieving the Update link ");
        return getLinkByName(RELATIONS_URI + "update");
    }

    public Link getSelfLink() 
    {
        LOG.info("Retrieving the Self link ");
        return getLinkByName("self");
    }
    
}
