/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.appeal.resources;

import com.appeal.activities.AppealDeletionException;
import com.appeal.activities.CreateNewAppeal;
import com.appeal.activities.DeleteAppeal;
import com.appeal.activities.InvalidAppealException;
import com.appeal.activities.NoSuchAppealException;
import com.appeal.activities.RetrieveAppeal;
import com.appeal.activities.UpdateAppeal;
import com.appeal.model.AppealStatus;
import com.appeal.representations.AppealRepresentation;
import com.appeal.representations.AppealsURI;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.POST;
import javax.ws.rs.core.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * REST Web Service
 *
 * @author Shruti Sonawane
 */
@Path("/appeal")
public class AppealResource 
{
    private static final Logger LOG = LoggerFactory.getLogger(AppealResource.class);

    @Context
    private UriInfo uriInfo;

    /**
     * Creates a new instance of AppealResource
     */
    public AppealResource() 
    {
        LOG.info("Inside AppealResource constructor");
    }

    public AppealResource(UriInfo uriInfo) 
    {
        LOG.info("AppealResource constructor with mock uriInfo {}", uriInfo);
        this.uriInfo = uriInfo;  
    }
    /**
     * Retrieves representation of an instance of com.appeal.resources.AppealResource
     * @return an instance of java.lang.String
     */
    @GET
    @Path("/{appealID}")
    @Produces("application/vnd-cse564-appeals+xml")
    public Response getAppeal() 
    {
        LOG.info("Retrieving an Appeal Resource");
        Response response;
        try 
        {
            AppealRepresentation responseRepresentation = new RetrieveAppeal().retrieveAppealByUri(new AppealsURI(uriInfo.getRequestUri()));
            response = Response.status(Response.Status.OK).entity(responseRepresentation).build();
        } 
        catch(NoSuchAppealException nsae) 
        {
            LOG.debug("No such appeal exists");
            response = Response.status(Response.Status.NOT_FOUND).build();
        } 
        catch (Exception ex) 
        {
            LOG.debug("Something went wrong retriving the appeal");
            response = Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }
        LOG.debug("Retrieved the appeal resource", response);
        return response;
    }

    @POST
    @Consumes("application/vnd-cse564-appeals+xml")
    @Produces("application/vnd-cse564-appeals+xml")
    public Response createAppeal(String appealRepresentation) 
    {
        LOG.info("Creating a new Appeal Resource");
        Response response;
        try 
        {
            AppealRepresentation responseRepresentation = new CreateNewAppeal().create(AppealRepresentation.fromXmlString(appealRepresentation).getAppeal(), new AppealsURI(uriInfo.getRequestUri()));
            response = Response.created(responseRepresentation.getUpdateLink().getUri()).entity(responseRepresentation).build();
        } 
        catch (InvalidAppealException iae) 
        {
            LOG.debug("Invalid Appeal - Problem with the appeal representation {}", appealRepresentation);
            response = Response.status(Response.Status.BAD_REQUEST).build();
        } 
        catch (Exception ex) 
        {
            LOG.info("Someting went wrong creating the appeal resource");
            response = Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }       
        LOG.debug("Resulting response for creating the appeal resource is {}", response);
        return response;
    }
    
    @POST
    @Path("/{appealID}")
    @Consumes("application/vnd-cse564-appeals+xml")
    @Produces("application/vnd-cse564-appeals+xml")
    public Response updateAppeal(String appealRepresentation) 
    {
       LOG.info("Updating an Appeal Resource");
        Response response;
        try 
        {
            AppealRepresentation responseRepresentation = new UpdateAppeal().update(AppealRepresentation.fromXmlString(appealRepresentation).getAppeal(), new AppealsURI(uriInfo.getRequestUri()));
            response = Response.created(responseRepresentation.getUpdateLink().getUri()).entity(responseRepresentation).build();
        } 
        catch (InvalidAppealException iae) 
        {
            LOG.debug("Invalid Appeal - Problem with the appeal representation {}", appealRepresentation);
            response = Response.status(Response.Status.BAD_REQUEST).build();
        } 
        catch (Exception ex) 
        {
            LOG.debug("Someting went wrong while updating the appeal resource");
            response = Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }       
        LOG.debug("Resulting response for updating the appeal resource is {}", response);
        return response;
    }
    
    @DELETE
    @Path("/{appealID}")
    @Produces("application/vnd-cse564-appeals+xml")
    public Response deleteAppeal() 
    {
        LOG.info("Deleting an Appeal Reource");      
        Response response;
        try 
        {
            AppealRepresentation deletedAppeal = new DeleteAppeal().deleteAppeal(new AppealsURI(uriInfo.getRequestUri()));
            deletedAppeal.getAppeal().setStatus(AppealStatus.WITHDRAWN);
            response = Response.status(Response.Status.OK).entity(deletedAppeal).build();
        } 
        catch (NoSuchAppealException nsae) 
        {
            LOG.debug("No such appeal resource to delete");
            response = Response.status(Response.Status.NOT_FOUND).build();
        } 
        catch(AppealDeletionException ade) 
        {
            LOG.debug("Problem deleting appeal resource");
            response = Response.status(Response.Status.METHOD_NOT_ALLOWED).header("Allow", "GET").build();
        } 
        catch (Exception ex) 
        {
            LOG.debug("Something went wrong deleting the appeal resource");
            response = Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }   
        LOG.debug("Resulting response for deleting the appeal resource is {}", response);    
        return response;
    }
}
