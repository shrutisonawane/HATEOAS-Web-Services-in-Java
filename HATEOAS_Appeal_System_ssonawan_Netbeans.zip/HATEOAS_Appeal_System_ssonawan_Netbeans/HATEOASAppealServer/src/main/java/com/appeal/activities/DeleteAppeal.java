/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.appeal.activities;
import com.appeal.representations.*;
import com.appeal.activities.*;
import com.appeal.model.*;
import com.appeal.repositories.*;
import com.appeal.resources.AppealResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Shruti Sonawane
 */
public class DeleteAppeal 
{
     private static final Logger LOG = LoggerFactory.getLogger(DeleteAppeal.class);
     
    public AppealRepresentation deleteAppeal(AppealsURI appealUri) 
    {
       LOG.info("Inside deleteAppeal method");
        // Understand the uri of the appeal that is being deleted        
        AppealIDGenerator aID = appealUri.getId();
        AppealRepository appealRepository = AppealRepository.current();

        if (!appealRepository.appealExists(aID)) 
        {
            throw new NoSuchAppealException();
        }

        Appeal appeal = appealRepository.getAppeal(aID);

        // Can't delete an appeal if it is under review
        if ((appeal.getStatus()== AppealStatus.UNDER_REVIEW)) 
        {
            throw new AppealDeletionException();
        }

        //an appeal that has been accepted or rejected or withdrawn or is new can be deleted
        if((appeal.getStatus() == AppealStatus.ACCEPTED) || (appeal.getStatus() == AppealStatus.REJECTED) ||
                (appeal.getStatus()== AppealStatus.WITHDRAWN)||(appeal.getStatus() == AppealStatus.NEW)) 
        {
            appealRepository.removeAppeal(aID);
        }

        return new AppealRepresentation(appeal);
    }
    
}
