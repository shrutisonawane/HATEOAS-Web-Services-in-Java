/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.appeal.activities;

import com.appeal.model.Appeal;
import com.appeal.model.AppealIDGenerator;
import com.appeal.model.AppealStatus;
import com.appeal.repositories.AppealRepository;
import com.appeal.representations.AppealRepresentation;
import com.appeal.representations.AppealsURI;

/**
 *
 * @author Shruti Sonawane
 */
public class RetrieveAppeal 
{
    public AppealRepresentation retrieveAppealByUri(AppealsURI appealUri) 
    {
        AppealIDGenerator identifier  = appealUri.getId();
        
        Appeal appeal = AppealRepository.current().getAppeal(identifier);
        
        if(appeal == null) 
        {
            throw new NoSuchAppealException();
        }
        else
        {
            if(appeal.getStatus()==AppealStatus.NEW)
                appeal.setStatus(AppealStatus.FORGOTTEN);
        }
        return AppealRepresentation.createResponseAppealRepresentation(appeal, appealUri);
    }
    
}
