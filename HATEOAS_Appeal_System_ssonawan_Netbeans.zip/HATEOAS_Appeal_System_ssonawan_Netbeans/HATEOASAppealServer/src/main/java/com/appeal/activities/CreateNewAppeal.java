/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.appeal.activities;
import com.appeal.representations.*;
import com.appeal.model.*;
import com.appeal.repositories.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 *
 * @author Shruti Sonawane
 */
public class CreateNewAppeal 
{
    private static final Logger LOG = LoggerFactory.getLogger(AppealRepository.class);
    
    public AppealRepresentation create(Appeal appeal, AppealsURI requestUri) 
    {
        appeal.setStatus(AppealStatus.NEW);
        AppealIDGenerator identifier = AppealRepository.current().addAppeal(appeal);
        LOG.info("Creating a new appeal with id {}",identifier);
        
        AppealsURI appealUri = new AppealsURI(requestUri.getBaseUri() + "/appeal/" + identifier.toString());
        return new AppealRepresentation(appeal, 
                new Link(Representation.RELATIONS_URI + "delete", appealUri), 
                new Link(Representation.RELATIONS_URI + "process", appealUri),
                new Link(Representation.RELATIONS_URI + "update", appealUri),
                new Link(Representation.RELATIONS_URI + "submit", appealUri),
                new Link(Representation.SELF_REL_VALUE, appealUri));
    }
    
}
