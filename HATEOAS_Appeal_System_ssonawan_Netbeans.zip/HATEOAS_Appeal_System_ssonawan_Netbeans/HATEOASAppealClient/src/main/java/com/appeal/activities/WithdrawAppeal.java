/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.appeal.activities;

import com.appeal.model.AppealIDGenerator;
import com.appeal.repositories.AppealRepository;
import com.appeal.representations.AppealRepresentation;
import com.appeal.model.*;

/**
 *
 * @author Shruti Sonawane
 */
public class WithdrawAppeal 
{
    public AppealRepresentation WithdrawAppeal(AppealIDGenerator appealID)
    {
         AppealRepository appRepository = AppealRepository.current();
        if (appRepository.appealExists(appealID)) 
        {
           Appeal app = appRepository.getAppeal(appealID);
           if((app.getStatus()== AppealStatus.FORGOTTEN) || (app.getStatus()== AppealStatus.NEW))
           {
               appRepository.removeAppeal(appealID);
                return new AppealRepresentation(app);
           }
           else
           {
               throw new CannotWithdrawSubmittedAppeal();
           }
        }
        else
        {
            throw new NoSuchAppealException();
        }
       
    }
    
}
