/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.appeal.client;
import com.appeal.model.*;
import static com.appeal.model.AppealBuilder.appeal;
import com.appeal.representations.*;
//import static com.sun.xml.internal.ws.api.message.Packet.State.ClientResponse;
import java.net.URI;
//import javax.ws.rs.client.Client;
import com.sun.jersey.api.client.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Shruti Sonawane
 */
public class Main 
{
    private static final Logger LOG = LoggerFactory.getLogger(Main.class);
    
    private static final String APPEAL_SYS_MEDIA_TYPE = "application/vnd-cse564-appeals+xml";
    private static final long ONE_MINUTE = 60000; 
    
    private static final String ENTRY_POINT_URI = "http://localhost:8080/HATEOASAppealServer/webresources/appeal";

    public static void main(String args[]) throws Exception
    {
        URI serviceUri = new URI(ENTRY_POINT_URI);
        happyPathTest(serviceUri);
        abandonedPathTest(serviceUri);
        forgottenPathTest(serviceUri);
        badStartPathTest(serviceUri);
        badIDPathTest(serviceUri);
    }
    
    private static void hangAround(long backOffTimeInMillis) 
    {
        try 
        {
            Thread.sleep(backOffTimeInMillis);
        } 
        catch (InterruptedException e) 
        {
            throw new RuntimeException(e);
        }
    }
    
    //Case 1: Happy case- client creates a requets to create new appeal and it completes as expected
    private static void happyPathTest(URI serviceUri) throws Exception 
    {
        LOG.info("\n*******************************Happy Case***************************************");
        LOG.info("Starting Happy Path Test with Service URI {}", serviceUri);
        // Create a new appeal
        LOG.info("Step 1: Create a new appeal");
        System.out.println(String.format("About to start happy path test. Creating a new appeal at [%s] via POST", serviceUri.toString()));
        
        Appeal appeal = appeal().build();
        LOG.info("Step 2: Created base appeal {}", appeal.toString());
        
         
        Client client = Client.create();
        LOG.info("Step 3: Created client {}", client);
        
        LOG.info("Step 4: Sending request to service URI "+ serviceUri.toString());
        
        AppealRepresentation appealRepresentation = client.resource(serviceUri).accept(APPEAL_SYS_MEDIA_TYPE).type(APPEAL_SYS_MEDIA_TYPE).post(AppealRepresentation.class, new ClientAppeal(appeal));
        LOG.info("Step 5: Created appealRepresentation {} denoted by the URI {}", appealRepresentation, appealRepresentation.getSelfLink().getUri().toString());
        System.out.println(String.format("Step 6: New appeal was created at [%s]", appealRepresentation.getSelfLink().getUri().toString()));
        LOG.info("Appeal state is: "+appealRepresentation.getAppeal().getStatus().toString());
    }
    
    //Case 2: Abandoned case: client creates an appeal but later decides to abandon it
     private static void abandonedPathTest(URI serviceUri) throws Exception 
    {
        LOG.info("\n\n.+*******************************Abandoned Case***************************************");
        LOG.info("Starting Abandoned Path Test with Service URI {}", serviceUri);
        // Create a new appeal
        LOG.info("Step 1: Create a new appeal");
        System.out.println(String.format("About to start abandoned path test. Creating a new appeal at [%s] via POST", serviceUri.toString()));
        
        Appeal appeal = appeal().build();
        LOG.info("Step 2: Created base appeal {}", appeal.toString());
        
         
        Client client = Client.create();
        LOG.info("Step 3: Created client {}", client);
        
        LOG.info("Step 4: Sending request to service URI "+ serviceUri.toString());
        
        AppealRepresentation appealRepresentation = client.resource(serviceUri).accept(APPEAL_SYS_MEDIA_TYPE).type(APPEAL_SYS_MEDIA_TYPE).post(AppealRepresentation.class, new ClientAppeal(appeal));
        LOG.info("Step 5: Created appealRepresentation {} denoted by the URI {}", appealRepresentation, appealRepresentation.getSelfLink().getUri().toString());
        System.out.println(String.format("Step 6: New appeal was created at [%s]", appealRepresentation.getSelfLink().getUri().toString()));

        //Now client decides to abandon the created appeal
        LOG.info("Step 7: Client decides to abandon the created appeal with Id "+appealRepresentation.getSelfLink().getUri().toString() );
        Link abandonLink = appealRepresentation.getDeleteLink();
        LOG.info("Abandon link: "+abandonLink.toString());
        AppealRepresentation abandonedAppeal = client.resource(abandonLink.getUri()).delete(AppealRepresentation.class);
        LOG.info("Appeal state is: WITHDRAWN");
        LOG.info("Step 8: Appeal for "+abandonedAppeal.getAppeal().getItemName() +" deleted");
        
    }
    
     //Case 3: Forgotten Case- Client creates a new appeal, but it is not yet processed and is forgotten.
     private static void forgottenPathTest(URI serviceUri) throws Exception 
    {
        LOG.info("\n\n*******************************Forgotten Case***************************************");
        LOG.info("Starting Forgotten Path Test with Service URI {}", serviceUri);
        // Create a new appeal
        LOG.info("Step 1: Create a new appeal");
        System.out.println(String.format("About to start forgotten path test. Creating a new appeal at [%s] via POST", serviceUri.toString()));
        
        Appeal appeal = appeal().build();
        LOG.info("Step 2: Created base appeal {}", appeal.toString());
        
         
        Client client = Client.create();
        LOG.info("Step 3: Created client {}", client);
        
        LOG.info("Step 4: Sending request to service URI "+ serviceUri.toString());
        
        AppealRepresentation appealRepresentation = client.resource(serviceUri).accept(APPEAL_SYS_MEDIA_TYPE).type(APPEAL_SYS_MEDIA_TYPE).post(AppealRepresentation.class, new ClientAppeal(appeal));
        LOG.info("Step 5: Created appealRepresentation {} denoted by the URI {}", appealRepresentation, appealRepresentation.getSelfLink().getUri().toString());
        System.out.println(String.format("Step 6: New appeal was created at [%s]", appealRepresentation.getSelfLink().getUri().toString()));

        Link processLink = appealRepresentation.getProcessLink();
        LOG.info("Step 7: The client appeal has not yet been processed and so it goes into the \"forgotten\" state");
        
        AppealRepresentation forgottenAppeal = client.resource(processLink.getUri()).get(AppealRepresentation.class);
        LOG.info("Appeal state is: "+ forgottenAppeal.getAppeal().getStatus().toString());
    }
     
     //Case 4: Bad Start- when the client tries the happy case but provides a bad URI 
     private static void badStartPathTest(URI serviceUri) throws Exception 
    {
        LOG.info("\n*******************************Bad Start Case***************************************");
        LOG.info("Starting Bad Start Path Test with Service URI {}", serviceUri);
        // Create a new appeal
        LOG.info("Step 1: Create a new appeal");
        System.out.println(String.format("About to start bad start path test. Creating a new appeal at [%s] via POST", serviceUri.toString()));
        
        Appeal appeal = appeal().build();
        LOG.info("Step 2: Created base appeal {}", appeal.toString());
                 
        Client client = Client.create();
        LOG.info("Step 3: Created client {}", client);
        
        Link badURI = new Link("bad", new AppealsURI(serviceUri + "/bad_uri"), APPEAL_SYS_MEDIA_TYPE);
        LOG.info("Step 4: Sending request to service URI "+ serviceUri.toString());
        try
        {
        AppealRepresentation appealRepresentation = client.resource(badURI.getUri()).accept(APPEAL_SYS_MEDIA_TYPE).type(APPEAL_SYS_MEDIA_TYPE).post(AppealRepresentation.class, new ClientAppeal(appeal));
        LOG.info("Step 5: Created appealRepresentation {} denoted by the URI {}", appealRepresentation, appealRepresentation.getSelfLink().getUri().toString());
        System.out.println(String.format("Step 6: New appeal was created at [%s]", appealRepresentation.getSelfLink().getUri().toString()));
        LOG.info("Appeal state is: "+appealRepresentation.getAppeal().getStatus().toString());
        }
        catch(UniformInterfaceException ex)
        {
            LOG.info("Client request contains a bad URI and error code is: "+ex.getResponse().getStatus());           //+ex.getResponse().getEntity(AppealRepresentation.class).getAppeal().getStatus());
        }
    }
     
     //Case 5: Bad ID- client is requesting for an invalid appealID
      private static void badIDPathTest(URI serviceUri) throws Exception 
    {
        LOG.info("\n\n*******************************Bad ID Case***************************************");
        LOG.info("Starting Bad ID Path Test with Service URI {}", serviceUri);
        // Create a new appeal
        LOG.info("Step 1: Create a new appeal");
        System.out.println(String.format("About to start forgotten path test with bad appealID. Creating a new appeal at [%s] via POST", serviceUri.toString()));
        
        Appeal appeal = appeal().build();
        LOG.info("Step 2: Created base appeal {}", appeal.toString());
           
        Client client = Client.create();
        LOG.info("Step 3: Created client {}", client);
        
        LOG.info("Step 4: Sending request to service URI "+ serviceUri.toString());
        
        AppealRepresentation appealRepresentation = client.resource(serviceUri).accept(APPEAL_SYS_MEDIA_TYPE).type(APPEAL_SYS_MEDIA_TYPE).post(AppealRepresentation.class, new ClientAppeal(appeal));
        LOG.info("Step 5: Created appealRepresentation {} denoted by the URI {}", appealRepresentation, appealRepresentation.getSelfLink().getUri().toString());
        System.out.println(String.format("Step 6: New appeal was created at [%s]", appealRepresentation.getSelfLink().getUri().toString()));

        Link badID = new Link("badID", new AppealsURI(serviceUri + "/9999"), APPEAL_SYS_MEDIA_TYPE);
        LOG.info("Step 7: BadID URI is: "+badID.getUri().toString());
        ClientResponse resp = client.resource(badID.getUri()).get(ClientResponse.class);
        LOG.info("Bad ID response code: "+resp.getStatus());
        LOG.info("Bad ID response message: "+resp.getStatusInfo());       //+resp.getEntity(String.class));
    }
     
     
     
}
