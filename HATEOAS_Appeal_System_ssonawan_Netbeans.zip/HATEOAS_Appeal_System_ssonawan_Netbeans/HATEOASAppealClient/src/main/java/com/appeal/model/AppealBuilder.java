/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.appeal.model;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 *
 * @author Shruti Sonawane
 */
public class AppealBuilder 
{
    private static final Logger LOG = LoggerFactory.getLogger(AppealBuilder.class);
    
    public static AppealBuilder appeal() 
    {
        return new AppealBuilder();
    }
    
    String demo[] = {"Assignment 1","Assignment 2","Assignment 3","Assignment 4", "Midterm 1","Midterm 2","Quiz 1","Quiz 2","Quiz 3"};
    String content[] = {"Need error handling","Missed Q3","Need to elaborate","Must give sample code"};    
    Random num = new Random();
    int i = num.nextInt(7);
    int j = num.nextInt(3);
    
    private String itemName = demo[i]; 
    private AppealStatus status = AppealStatus.NEW;
    private String appealContent = content[j];
        
    public Appeal build() 
    {
        LOG.debug("Executing AppealBuilder.build");
        return new Appeal(itemName,appealContent, status);
    }

    public AppealBuilder withStatus(AppealStatus status) 
    {
        LOG.debug("Executing AppealBuilder.withStatus");
        this.status = status;
        return this;
    }
}
