/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.appeal.activities;
import com.appeal.representations.*;
import com.appeal.activities.*;
import com.appeal.model.*;
import com.appeal.repositories.*;
/**
 *
 * @author Shruti Sonawane
 */
public class SubmitAppeal 
{
    public AppealRepresentation SubmitAppeal(AppealIDGenerator id) 
    {
        AppealRepository appRepository = AppealRepository.current();
        if (appRepository.appealExists(id)) 
        {
            Appeal appeal = appRepository.getAppeal(id);

            if (appeal.getStatus() == AppealStatus.NEW) 
            {
                appeal.setStatus(AppealStatus.UNDER_REVIEW);
            } 
            else if ((appeal.getStatus() == AppealStatus.ACCEPTED) || (appeal.getStatus() == AppealStatus.REJECTED) || 
                    (appeal.getStatus() == AppealStatus.UNDER_REVIEW) || (appeal.getStatus() == AppealStatus.FORGOTTEN)) 
            {
                throw new AppealAlreadySubmittedException();
            } 
            
            return new AppealRepresentation(appeal);
        } 
        else 
        {
            throw new NoSuchAppealException();
        }
    }
    
}
