/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.appeal.representations;
import java.net.URI;
import java.net.URISyntaxException;
import com.appeal.model.AppealIDGenerator;
/**
 *
 * @author Shruti Sonawane
 */
public class AppealsURI 
{
    private URI uri;
    
    public AppealsURI(String uri) 
    {
        try 
        {
            this.uri = new URI(uri);
        }
        catch (URISyntaxException e) 
        {
            throw new RuntimeException(e);
        }
    }
    
    public String getBaseUri() 
    {
        String uriString = uri.toString();
        String baseURI   = uriString.substring(0, uriString.lastIndexOf("webresources/")+"webresources".length());    
        return baseURI;
    }
    
    public AppealsURI(URI uri) 
    {
        this(uri.toString());
    }

    public AppealsURI(URI uri, AppealIDGenerator identifier) 
    {
        this(uri.toString() + "/" + identifier.toString());
    }

    public AppealIDGenerator getId() 
    {
        String path = uri.getPath();
        return new AppealIDGenerator(path.substring(path.lastIndexOf("/") + 1, path.length()));
    }

    public URI getFullUri() 
    {
        return uri;
    }
    
    @Override
    public String toString() 
    {
        return uri.toString();
    }
    
}
