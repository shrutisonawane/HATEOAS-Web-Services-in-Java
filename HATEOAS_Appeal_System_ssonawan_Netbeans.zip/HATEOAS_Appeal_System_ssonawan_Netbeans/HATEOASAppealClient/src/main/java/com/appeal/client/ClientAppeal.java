/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.appeal.client;
import com.appeal.activities.*;
import com.appeal.model.*;
import com.appeal.repositories.*;
import com.appeal.representations.*;
import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 *
 * @author Shruti Sonawane
 */
@XmlRootElement(name = "appeal", namespace = Representation.APPEAL_SYS_NAMESPACE)
public class ClientAppeal 
{
    private static final Logger LOG = LoggerFactory.getLogger(ClientAppeal.class);
    
    @XmlElement(name = "itemName", namespace = Representation.APPEAL_SYS_NAMESPACE)
    private String itemName;
    @XmlElement(name = "appealContent", namespace = Representation.APPEAL_SYS_NAMESPACE)
    private String appealContent;
    @XmlElement(name = "status", namespace = Representation.APPEAL_SYS_NAMESPACE)
    private AppealStatus status;
    
    private ClientAppeal(){}
    
    public ClientAppeal(Appeal appeal) 
    {
        LOG.debug("Executing ClientAppeal constructor");
        this.itemName = appeal.getItemName();
        this.appealContent = appeal.getAppealContent();
        this.status = appeal.getStatus();
    }
    
    public Appeal getAppeal() 
    {
        LOG.debug("Executing ClientAppeal.getAppeal");
        return new Appeal(itemName,appealContent,status);
    }
    
    public String getItemName() 
    {
        LOG.debug("Executing ClientAppeal.getItemName");
        return itemName;
    }
    
    public String getAppealContent()
    {
        LOG.debug("Executing ClientAppeal.getAppealContent");
        return appealContent;
    }
    
     public AppealStatus getStatus() 
     {
        LOG.debug("Executing ClientAppeal.getStatus");
        return status;
    }

    
}
