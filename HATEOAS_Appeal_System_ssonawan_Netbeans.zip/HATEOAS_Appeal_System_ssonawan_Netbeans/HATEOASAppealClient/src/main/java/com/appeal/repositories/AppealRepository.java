/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.appeal.repositories;
import java.util.HashMap;
import java.util.Map.Entry;
//import com.appeal.model.AppealList;
import com.appeal.model.Appeal;
import com.appeal.model.AppealIDGenerator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 *
 * @author Shruti Sonawane
 */
public class AppealRepository 
{
   private static final Logger LOG = LoggerFactory.getLogger(AppealRepository.class);
   
   private static final AppealRepository theRepository = new AppealRepository();
   private HashMap<String, Appeal> appealRepository = new HashMap<>();
   
   public static AppealRepository current() 
   {
        return theRepository;
    }
        
   private AppealRepository()
   {
       LOG.debug("Inside AppealRepository constructor");
   }
   
   //get a stored appeal
   public Appeal getAppeal(AppealIDGenerator appealID)
   {
       LOG.debug("Retrieving Appeal object for appealID {}", appealID.toString());
       return appealRepository.get(appealID.toString());
   }
   
   //after appeal is processed
    public Appeal processAppeal(AppealIDGenerator appealID) 
    {
        LOG.debug("Removing the Appeal object for appealID {}", appealID);
        Appeal appeal = appealRepository.get(appealID.toString());
        appealRepository.remove(appealID.toString());
        return appeal;
    }
    
    //adding a new appeal
    public AppealIDGenerator addAppeal(Appeal newAppeal)
    {
        AppealIDGenerator appealID = new AppealIDGenerator();
        LOG.debug("Adding a new Appeal object with appealID {}", appealID);
        appealRepository.put(appealID.toString(), newAppeal);
        return appealID;
    }
    
    //updating and overwriting an appeal
    public void updateAppeal(AppealIDGenerator id, Appeal updatedAppeal)
    {
        LOG.debug("Updating the appeal with appealID {}", id.toString());
        appealRepository.put(id.toString(),updatedAppeal);
    }
    
    //checking whether an appeal already exists 
    public boolean appealExists(AppealIDGenerator appealID)
    {
        LOG.debug("Checking if an appeal with appealID {} exists in memory", appealID);
        if(appealRepository.containsKey(appealID.toString()))
            return true;
        else
            return false;
    }
    
    //removing an appeal
    public void removeAppeal(AppealIDGenerator appealID)
    {
       LOG.debug("Removing the Appeal object for appealID {}", appealID.toString());
       appealRepository.remove(appealID.toString());
    }
   
}
