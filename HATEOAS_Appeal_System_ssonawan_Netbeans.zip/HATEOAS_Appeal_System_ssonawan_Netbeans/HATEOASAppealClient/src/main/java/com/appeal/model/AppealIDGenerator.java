/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.appeal.model;

/**
 *
 * @author Shruti Sonawane
 */
public class AppealIDGenerator 
{
    private final String identifier;

    public AppealIDGenerator(String identifier) 
    {
        this.identifier = identifier;
    }
    
    public AppealIDGenerator() 
    {
        this(java.util.UUID.randomUUID().toString());
    }

    public String toString() 
    {
        return identifier;
    }
    
}
