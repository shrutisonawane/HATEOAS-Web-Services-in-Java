/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.appeal.activities;
import com.appeal.representations.*;
import com.appeal.model.*;
import com.appeal.repositories.*;
/**
 *
 * @author Shruti Sonawane
 */
public class UpdateAppeal 
{
    public AppealRepresentation update(Appeal appeal, AppealsURI appealUri) 
    {
        AppealIDGenerator appealID = appealUri.getId();
        Appeal appToBeUpdated;

        AppealRepository repo = AppealRepository.current();
        if (AppealRepository.current().appealExists(appealID)) 
        { 
            if (AppealCanBeUpdated(appealID)) 
            {
               appToBeUpdated = repo.getAppeal(appealID);
               appToBeUpdated.setAppealContent(appeal.getAppealContent());
               appToBeUpdated.setItemName(appeal.getItemName());
               appToBeUpdated.setStatus(appeal.getStatus());
               repo.updateAppeal(appealID,appToBeUpdated);
            }  
            else
            {
               throw new UpdateException(); 
            }
        }
        else
        {
            throw new NoSuchAppealException();
        }     
        return AppealRepresentation.createResponseAppealRepresentation(appToBeUpdated, appealUri); 
    }
    
    public boolean AppealCanBeUpdated(AppealIDGenerator aID)
    {
        Appeal a = AppealRepository.current().getAppeal(aID);
        if(a.getStatus()== AppealStatus.NEW || a.getStatus() == AppealStatus.FORGOTTEN)
            return true;
        else
           return false;
    }
    
}
