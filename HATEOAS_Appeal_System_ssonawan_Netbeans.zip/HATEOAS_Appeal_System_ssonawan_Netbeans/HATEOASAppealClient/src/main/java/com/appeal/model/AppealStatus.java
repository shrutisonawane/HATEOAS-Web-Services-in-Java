/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.appeal.model;
import javax.xml.bind.annotation.XmlEnumValue;
/**
 *
 * @author Shruti Sonawane
 */
public enum AppealStatus 
{
    @XmlEnumValue(value="new")    
    NEW,
    
    @XmlEnumValue(value="under review")
    UNDER_REVIEW,
    
    @XmlEnumValue(value="forgotten")
    FORGOTTEN,
    
    @XmlEnumValue(value="accepted")
    ACCEPTED,
        
    @XmlEnumValue(value="rejected")
    REJECTED,
    
    @XmlEnumValue(value="withdrawn")
    WITHDRAWN
}
