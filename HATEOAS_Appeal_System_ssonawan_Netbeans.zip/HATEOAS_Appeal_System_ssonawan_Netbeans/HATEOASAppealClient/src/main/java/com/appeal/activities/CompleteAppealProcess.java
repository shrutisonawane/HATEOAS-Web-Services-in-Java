/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.appeal.activities;
import com.appeal.representations.*;
import com.appeal.model.*;
import com.appeal.repositories.*;
import java.util.Random;
/**
 *
 * @author Shruti Sonawane
 */
public class CompleteAppealProcess 
{
     public AppealRepresentation CompleteAppealProcess(AppealIDGenerator id) 
     {
        AppealRepository appealRepo = AppealRepository.current();
        if (appealRepo.appealExists(id)) 
        {
            Appeal appeal = appealRepo.getAppeal(id);

            if (appeal.getStatus() == AppealStatus.UNDER_REVIEW) 
            {
                //Randomly assign the status as ACCEPTED or REJECTED
                Random randNum = new Random();
                int i = randNum.nextInt(100);
                if(i%2==0)            
                   appeal.setStatus(AppealStatus.ACCEPTED);
                else
                   appeal.setStatus(AppealStatus.REJECTED); 
            } 
            else if ((appeal.getStatus() == AppealStatus.ACCEPTED) || (appeal.getStatus() == AppealStatus.REJECTED))
            {
                throw new AppealAlreadyCompletedException();
            } 
            return new AppealRepresentation(appeal);
        } 
        else 
        {
            throw new NoSuchAppealException();
        }
    }
}
